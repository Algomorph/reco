#pragma once

#include <kangaroo/Image.h>

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wc++11-narrowing"
#include <boost/gil/gil_all.hpp>
#pragma clang diagnostic pop

// TODO Test for PNG precence
#define HAVE_PNG

#ifdef HAVE_PNG
#define png_infopp_NULL (png_infopp)NULL
#define int_p_NULL (int*)NULL
#include <boost/gil/extension/io/png_io.hpp>
#endif // HAVE_PNG

void SaveGIL(const std::string filename, const roo::Image<uchar3,roo::TargetHost>& image)
{
    boost::gil::rgb8_view_t v = boost::gil::interleaved_view(image.w, image.h, reinterpret_cast<boost::gil::rgb8_ptr_t>(image.ptr), image.pitch);

#ifdef HAVE_PNG
    boost::gil::png_write_view(filename, v );
#else
    std::cerr << "libpng support not compiled in" << std::endl;
#endif
}

template<typename T, typename Manage>
void SaveGIL(const std::string filename, const roo::Image<T,roo::TargetDevice,Manage>& img)
{
    roo::Image<T,roo::TargetHost,roo::Manage> himg(img.w, img.h);
    himg.CopyFrom(img);
    SaveGIL(filename, himg);
}
