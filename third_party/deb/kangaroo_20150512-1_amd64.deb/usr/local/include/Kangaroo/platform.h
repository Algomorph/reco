#pragma once

#include <kangaroo/config.h>

#ifdef _MSVC_
#   include <kangaroo/kangaroo_export.h>
#else
#   define KANGAROO_EXPORT
#endif //_MSVC_