#pragma once

#include <kangaroo/platform.h>

namespace roo
{

}
