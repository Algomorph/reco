#pragma once

#include "Divergence.h"
#include "cu_rof_denoising.h"
#include "cu_tgv.h"
