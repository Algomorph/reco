#ifndef PANGOLIN_CONFIG_H
#define PANGOLIN_CONFIG_H

/*
 * Configuration Header for Pangolin
 */

/// Version
#define PANGOLIN_VERSION_MAJOR 0
#define PANGOLIN_VERSION_MINOR 2
#define PANGOLIN_VERSION_STRING "0.2"

/// Pangolin options
#define BUILD_PANGOLIN_GUI
#define BUILD_PANGOLIN_VARS
#define BUILD_PANGOLIN_VIDEO

/// Configured libraries
#define HAVE_CUDA
/* #undef HAVE_CVARS */

#define CPP11_NO_BOOST
#define HAVE_EIGEN
/* #undef HAVE_TOON */

/* #undef HAVE_DC1394 */
#define HAVE_V4L
/* #undef HAVE_FFMPEG */
#define HAVE_OPENNI
#define HAVE_OPENNI2
/* #undef HAVE_UVC */
/* #undef HAVE_DEPTHSENSE */

#define HAVE_GLEW
#define HAVE_GLUT
#define HAVE_FREEGLUT
/* #undef HAVE_APPLE_OPENGL_FRAMEWORK */
/* #undef HAVE_MODIFIED_OSXGLUT */
/* #undef HAVE_GLES */
/* #undef HAVE_GLES_2 */
/* #undef HAVE_OCULUS */

#define HAVE_BOOST_GIL
/* #undef HAVE_PNG */
#define HAVE_JPEG
#define HAVE_TIFF

/// Platform
#define _UNIX_
/* #undef _WIN_ */
/* #undef _OSX_ */
#define _LINUX_
/* #undef _ANDROID_ */
/* #undef _IOS_ */

/// Compiler
#define _GCC_
/* #undef _CLANG_ */
/* #undef _MSVC_ */

/// Defines generated when calling into Pangolin API. Not to be
/// used in compiled library code, only inlined header code.
#if (__cplusplus > 199711L) || (_MSC_VER >= 1700)
#define CALLEE_HAS_CPP11
#define CALLEE_HAS_RVALREF
#endif

#if (__cplusplus > 199711L) || (_MSC_VER >= 1800)
#define CALLEE_HAS_VARIADIC_TEMPLATES
#endif

#endif //PANGOLIN_CONFIG_H
