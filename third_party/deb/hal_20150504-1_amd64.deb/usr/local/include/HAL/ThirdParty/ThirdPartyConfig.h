#pragma once

/* #undef HAL_HAVE_TMIX */
/* #undef HAL_HAVE_LEXUSISF12 */
