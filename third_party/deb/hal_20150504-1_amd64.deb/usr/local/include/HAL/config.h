#pragma once

#define HAL_VERSION 0.2
#define Messages_VERSION 2

#include <HAL/ThirdParty/ThirdPartyConfig.h>
