#ifndef _CALIBU_CONFIG_H_
#define _CALIBU_CONFIG_H_

/// Version
#define CALIBU_VERSION_MAJOR 0
#define CALIBU_VERSION_MINOR 2
#define CALIBU_VERSION_STRING "0.2"

/// Platform
#define _UNIX_
/* #undef _WIN_ */
/* #undef _OSX_ */
#define _LINUX_
/* #undef _ANDROID_ */

/// Compiler
#define _GCC_
/* #undef _MSVC_ */

/// Optional Libraries
#define HAVE_OPENCV


#endif //_CALIBU_CONFIG_H_
