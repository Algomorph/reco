#ifndef _CVARS_CONFIG_H_
#define _CVARS_CONFIG_H_

#define CVARS_MAJOR_REV   2
#define CVARS_MINOR_REV   4
#define CVARS_PATCH_REV   0

#endif
